require("dotenv").config();

const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === "production";
const sessionSecret = process.env.SESSION_SECRET || "";

if (sessionSecret.length < 32) {
  console.error("Set SESSION_SECRET to a random secret of at least 32 characters in .env.");
  process.exit(1);
}
if (!process.env.OWNER_PASSWORD || process.env.OWNER_PASSWORD.startsWith("replace-")) {
  console.error("Set a strong OWNER_PASSWORD in .env before starting the server.");
  process.exit(1);
}

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "best-empire.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('owner','admin')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    price REAL NOT NULL CHECK(price >= 0),
    description TEXT NOT NULL DEFAULT '',
    image_data TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

const userCount = db.prepare("SELECT COUNT(*) AS count FROM users").get().count;
if (userCount === 0) {
  const username = String(process.env.OWNER_USERNAME || "programmer").trim();
  if (!/^[a-zA-Z0-9_.-]{3,40}$/.test(username)) {
    console.error("OWNER_USERNAME must be 3-40 characters: letters, numbers, dot, underscore or hyphen.");
    process.exit(1);
  }
  const passwordHash = bcrypt.hashSync(process.env.OWNER_PASSWORD, 12);
  db.prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'owner')")
    .run(username, passwordHash);
  console.log(`Created first owner account: ${username}`);
}

app.disable("x-powered-by");
if (isProduction) app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: "3mb" }));
app.use(express.urlencoded({ extended: false, limit: "3mb" }));

app.use(session({
  name: "bestempire.sid",
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir }),
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "strict",
    secure: isProduction,
    maxAge: 1000 * 60 * 60 * 4
  }
}));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many login attempts. Try again in 15 minutes." }
});

function currentUser(req) {
  if (!req.session.userId) return null;
  return db.prepare("SELECT id, username, role FROM users WHERE id = ?").get(req.session.userId) || null;
}
function requireLogin(req, res, next) {
  const user = currentUser(req);
  if (!user) return res.status(401).json({ error: "Please log in." });
  req.user = user;
  next();
}
function requireOwner(req, res, next) {
  if (req.user.role !== "owner") return res.status(403).json({ error: "Programmer/owner permission required." });
  next();
}
function cleanText(value, max) {
  return String(value ?? "").trim().slice(0, max);
}
function validUsername(username) {
  return /^[a-zA-Z0-9_.-]{3,40}$/.test(username);
}
function validPassword(password) {
  return typeof password === "string" && password.length >= 12 && password.length <= 200;
}

app.get("/api/me", (req, res) => {
  const user = currentUser(req);
  res.json({ user: user ? { username: user.username, role: user.role } : null });
});

app.post("/api/login", loginLimiter, (req, res, next) => {
  const username = cleanText(req.body.username, 40);
  const password = typeof req.body.password === "string" ? req.body.password : "";
  const user = db.prepare("SELECT * FROM users WHERE username = ?").get(username);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: "Invalid username or password." });
  }
  req.session.regenerate(err => {
    if (err) return next(err);
    req.session.userId = user.id;
    req.session.save(saveErr => {
      if (saveErr) return next(saveErr);
      res.json({ user: { username: user.username, role: user.role } });
    });
  });
});

app.post("/api/logout", requireLogin, (req, res, next) => {
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie("bestempire.sid", { httpOnly: true, sameSite: "strict", secure: isProduction });
    res.json({ ok: true });
  });
});

// Admin management is OWNER ONLY. Ordinary admins cannot add, delete, or promote admins.
app.get("/api/admins", requireLogin, requireOwner, (req, res) => {
  res.json(db.prepare("SELECT id, username, role, created_at FROM users ORDER BY id").all());
});
app.post("/api/admins", requireLogin, requireOwner, (req, res) => {
  const username = cleanText(req.body.username, 40);
  const password = req.body.password;
  if (!validUsername(username)) return res.status(400).json({ error: "Username must be 3-40 characters using letters, numbers, dot, underscore or hyphen." });
  if (!validPassword(password)) return res.status(400).json({ error: "Use a password of at least 12 characters." });
  try {
    const result = db.prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'admin')")
      .run(username, bcrypt.hashSync(password, 12));
    res.status(201).json({ id: result.lastInsertRowid, username, role: "admin" });
  } catch (err) {
    if (String(err.code).includes("SQLITE_CONSTRAINT")) return res.status(409).json({ error: "That username already exists." });
    throw err;
  }
});
app.delete("/api/admins/:id", requireLogin, requireOwner, (req, res) => {
  const id = Number(req.params.id);
  const target = db.prepare("SELECT id, role, username FROM users WHERE id = ?").get(id);
  if (!target) return res.status(404).json({ error: "Admin not found." });
  if (target.role === "owner") return res.status(403).json({ error: "The owner account cannot be deleted from this screen." });
  db.prepare("DELETE FROM users WHERE id = ?").run(id);
  res.json({ ok: true });
});
app.post("/api/change-password", requireLogin, (req, res) => {
  const current = typeof req.body.currentPassword === "string" ? req.body.currentPassword : "";
  const next = req.body.newPassword;
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user.id);
  if (!bcrypt.compareSync(current, user.password_hash)) return res.status(400).json({ error: "Current password is incorrect." });
  if (!validPassword(next)) return res.status(400).json({ error: "New password must be at least 12 characters." });
  db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(bcrypt.hashSync(next, 12), req.user.id);
  res.json({ ok: true });
});

// Product management: logged-in admins can edit products; owner has all permissions.
app.get("/api/products", (req, res) => {
  const products = db.prepare("SELECT id, title, price, description, image_data AS image, updated_at FROM products ORDER BY id DESC").all();
  res.json(products);
});
app.post("/api/products", requireLogin, (req, res) => {
  const title = cleanText(req.body.title, 100);
  const description = cleanText(req.body.description, 240);
  const price = Number(req.body.price);
  const image = typeof req.body.image === "string" ? req.body.image : "";
  if (!title || !Number.isFinite(price) || price < 0) return res.status(400).json({ error: "Enter a title and a valid non-negative price." });
  if (image.length > 2_500_000 || (image && !/^data:image\/(jpeg|png|webp);base64,/.test(image))) {
    return res.status(400).json({ error: "Image must be JPEG, PNG, or WebP and under about 1.8 MB." });
  }
  const result = db.prepare("INSERT INTO products (title, price, description, image_data) VALUES (?, ?, ?, ?)")
    .run(title, price, description, image);
  res.status(201).json({ id: result.lastInsertRowid });
});
app.put("/api/products/:id", requireLogin, (req, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare("SELECT * FROM products WHERE id = ?").get(id);
  if (!existing) return res.status(404).json({ error: "Product not found." });
  const title = cleanText(req.body.title, 100);
  const description = cleanText(req.body.description, 240);
  const price = Number(req.body.price);
  const image = typeof req.body.image === "string" ? req.body.image : existing.image_data;
  if (!title || !Number.isFinite(price) || price < 0) return res.status(400).json({ error: "Enter a title and a valid non-negative price." });
  if (image.length > 2_500_000 || (image && !/^data:image\/(jpeg|png|webp);base64,/.test(image))) {
    return res.status(400).json({ error: "Image must be JPEG, PNG, or WebP and under about 1.8 MB." });
  }
  db.prepare("UPDATE products SET title=?, price=?, description=?, image_data=?, updated_at=CURRENT_TIMESTAMP WHERE id=?")
    .run(title, price, description, image, id);
  res.json({ ok: true });
});
app.delete("/api/products/:id", requireLogin, (req, res) => {
  const result = db.prepare("DELETE FROM products WHERE id = ?").run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Product not found." });
  res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, "public")));
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "public", "storefront.html")));
app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "public", "login.html")));
app.get("/dashboard", (req, res) => res.sendFile(path.join(__dirname, "public", "dashboard.html")));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "An unexpected server error occurred." });
});

app.listen(PORT, () => console.log(`BEST EMPIRE website running on http://localhost:${PORT}`));
