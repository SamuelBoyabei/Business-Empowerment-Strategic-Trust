const grid=document.getElementById("storeGrid");let all=[];
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function money(n){return new Intl.NumberFormat("en-SL",{style:"currency",currency:"SLE",maximumFractionDigits:2}).format(Number(n)||0);}
function render(){const q=document.getElementById("search").value.trim().toLowerCase();const list=all.filter(p=>(p.title+" "+p.description).toLowerCase().includes(q));grid.innerHTML="";if(!list.length){grid.innerHTML='<p class="empty">No products or services published yet.</p>';return;}list.forEach(p=>{const card=document.createElement("article");card.className="store-card";card.innerHTML=`<img alt="${esc(p.title)}"><div class="store-body"><h3>${esc(p.title)}</h3><p class="price">${money(p.price)}</p><p>${esc(p.description||"")}</p></div>`;const img=card.querySelector("img");img.src=p.image||"data:image/svg+xml,"+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="500" height="300"><rect width="100%" height="100%" fill="#201a0a"/><text x="50%" y="55%" text-anchor="middle" fill="#ffdf68" font-size="28">BEST EMPIRE</text></svg>');grid.append(card);});}
async function load(){try{const r=await fetch("/api/products");all=await r.json();render();}catch(e){grid.innerHTML='<p class="empty">Products could not load. Please try again later.</p>';}}
document.getElementById("search").addEventListener("input",render);
load();
// Refresh public data periodically so visitor pages pick up administrator edits.
setInterval(load,30000);
