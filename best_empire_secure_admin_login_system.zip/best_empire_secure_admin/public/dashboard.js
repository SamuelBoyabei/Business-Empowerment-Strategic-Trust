let currentUser = null;
let productsCache = [];
let selectedImage = "";
const $ = id => document.getElementById(id);
const statusBox = $("status");
function say(text, bad=false) { statusBox.textContent = text; statusBox.className = "message" + (bad ? " error" : ""); }
async function api(url, options={}) {
  const response = await fetch(url, { ...options, headers: { ...(options.body ? {"Content-Type":"application/json"} : {}), ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (response.status === 401) { location.href = "/admin"; throw new Error("Please sign in again."); }
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}
function money(n) { return new Intl.NumberFormat("en-SL",{style:"currency",currency:"SLE",maximumFractionDigits:2}).format(Number(n)||0); }
function escapeHtml(s) { return String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
async function loadProducts() {
  productsCache = await api("/api/products");
  const root = $("products"); root.innerHTML = "";
  if (!productsCache.length) { root.innerHTML = '<p class="muted">No products yet. Add the first item above.</p>'; return; }
  for (const p of productsCache) {
    const row = document.createElement("article"); row.className = "product-row";
    row.innerHTML = `<img src="${p.image || "/placeholder.svg"}" alt=""><div class="product-info"><strong>${escapeHtml(p.title)}</strong><span>${money(p.price)}</span><small>${escapeHtml(p.description)}</small></div><div class="row-buttons"><button class="dark-btn" data-edit="${p.id}">Edit</button><button class="delete-btn" data-delete="${p.id}">Delete</button></div>`;
    if (!p.image) row.querySelector("img").src = "data:image/svg+xml," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="160" height="100"><rect width="100%" height="100%" fill="#201a0a"/><text x="50%" y="55%" text-anchor="middle" fill="#ffdf68" font-size="18">BEST EMPIRE</text></svg>');
    root.append(row);
  }
}
function clearProductForm() { $("productForm").reset(); $("productId").value=""; selectedImage=""; $("saveProduct").textContent="Save product"; }
$("products").addEventListener("click", async e => {
  const edit = e.target.closest("[data-edit]"), del = e.target.closest("[data-delete]");
  try {
    if (edit) {
      const p = productsCache.find(x => x.id === Number(edit.dataset.edit)); if (!p) return;
      $("productId").value=p.id; $("title").value=p.title; $("price").value=p.price; $("description").value=p.description || ""; selectedImage=p.image || ""; $("saveProduct").textContent="Update product";
      $("productForm").scrollIntoView({behavior:"smooth"});
    }
    if (del) {
      const p=productsCache.find(x=>x.id===Number(del.dataset.delete)); if (!p || !confirm(`Delete "${p.title}"?`)) return;
      await api(`/api/products/${p.id}`,{method:"DELETE"}); await loadProducts(); say("Product deleted.");
    }
  } catch(err) { say(err.message,true); }
});
$("imageFile").addEventListener("change", async () => {
  const file=$("imageFile").files[0]; if (!file) return;
  if (!["image/jpeg","image/png","image/webp"].includes(file.type) || file.size > 1.8*1024*1024) { say("Choose a JPEG, PNG, or WebP image under about 1.8 MB.",true); $("imageFile").value=""; return; }
  selectedImage=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);});
});
$("productForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const id=$("productId").value;
    const body={title:$("title").value,price:Number($("price").value),description:$("description").value,image:selectedImage};
    await api(id?`/api/products/${id}`:"/api/products",{method:id?"PUT":"POST",body:JSON.stringify(body)});
    clearProductForm(); await loadProducts(); say("Product saved. The public storefront will show the latest data.");
  } catch(err) { say(err.message,true); }
});
$("clearProduct").addEventListener("click",clearProductForm);
$("logoutBtn").addEventListener("click",async()=>{
  try { await api("/api/logout",{method:"POST"}); location.href="/admin"; }
  catch(err) { say(err.message,true); }
});
$("adminForm").addEventListener("submit",async e=>{
  e.preventDefault();
  try {
    await api("/api/admins",{method:"POST",body:JSON.stringify({username:$("newUsername").value,password:$("newPassword").value})});
    $("adminForm").reset(); await loadAdmins(); say("Administrator account created. Share the credentials securely and ask them to change the password.");
  } catch(err) { say(err.message,true); }
});
async function loadAdmins() {
  const admins=await api("/api/admins"); const root=$("admins"); root.innerHTML="";
  admins.forEach(a=>{
    const row=document.createElement("div"); row.className="admin-row";
    row.innerHTML=`<span><strong>${escapeHtml(a.username)}</strong><small>${escapeHtml(a.role)} · created ${escapeHtml(a.created_at)}</small></span>${a.role==="owner" ? '<em>Protected owner</em>' : `<button class="delete-btn" data-remove-admin="${a.id}">Remove admin</button>`}`;
    root.append(row);
  });
}
$("admins").addEventListener("click",async e=>{
  const btn=e.target.closest("[data-remove-admin]"); if(!btn)return;
  if(!confirm("Remove this administrator's account?"))return;
  try { await api(`/api/admins/${btn.dataset.removeAdmin}`,{method:"DELETE"}); await loadAdmins(); say("Administrator removed."); }
  catch(err) { say(err.message,true); }
});
$("passwordForm").addEventListener("submit",async e=>{
  e.preventDefault();
  try {
    await api("/api/change-password",{method:"POST",body:JSON.stringify({currentPassword:$("currentPassword").value,newPassword:$("newPasswordChange").value})});
    $("passwordForm").reset(); say("Password changed successfully.");
  } catch(err) { say(err.message,true); }
});
(async()=>{
  try {
    const me=await api("/api/me"); currentUser=me.user;
    if(!currentUser){location.href="/admin";return;}
    document.querySelector(".topbar strong").textContent=`BEST EMPIRE · ${currentUser.username}`;
    if(currentUser.role==="owner"){ $("ownerPanel").hidden=false; await loadAdmins(); }
    await loadProducts();
  } catch(err) { say(err.message,true); }
})();
