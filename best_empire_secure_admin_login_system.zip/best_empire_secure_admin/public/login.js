document.getElementById("loginForm").addEventListener("submit", async event => {
  event.preventDefault();
  const message = document.getElementById("message");
  message.textContent = "Signing in…";
  try {
    const response = await fetch("/api/login", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: document.getElementById("username").value,
        password: document.getElementById("password").value
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Login failed.");
    location.href = "/dashboard";
  } catch (error) { message.textContent = error.message; }
});
fetch("/api/me").then(r => r.json()).then(data => { if (data.user) location.href = "/dashboard"; }).catch(() => {});
